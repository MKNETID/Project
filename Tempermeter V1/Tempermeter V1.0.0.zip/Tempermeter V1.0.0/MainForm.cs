﻿using HidSharp;
using OpenHardwareMonitor.Hardware;
using Microsoft.Win32.TaskScheduler;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
// Gunakan alias atau panggil langsung untuk menghindari ambiguitas
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace Tempermeter
{
    public partial class MainForm : Form
    {
        private const int VENDOR_ID = 0x5131;
        private const int PRODUCT_ID = 0x2007;
        private const string TASK_NAME = "Tempermeter_AutoStart";

        private BackgroundWorker _worker;
        private Computer _computer;
        private bool _isMonitoring = false;
        private NotifyIcon _trayIcon;

        public MainForm()
        {
            InitializeComponent();
            SetupWorker();
            SetupTrayIcon();

            this.FormClosing += MainForm_FormClosing;
            this.btnApply.Click += btnApply_Click;
        }

        private void SetupTrayIcon()
        {
            _trayIcon = new NotifyIcon();
            _trayIcon.Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            _trayIcon.Text = "Tempermeter Monitoring";

            _trayIcon.DoubleClick += (s, e) => ShowWindow();

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add("Buka Aplikasi", null, (s, e) => ShowWindow());
            menu.Items.Add("-");
            menu.Items.Add("Keluar Total", null, (s, e) => ExitApp());
            _trayIcon.ContextMenuStrip = menu;
        }

        private void SetupWorker()
        {
            _worker = new BackgroundWorker { WorkerSupportsCancellation = true };
            _worker.DoWork += Worker_DoWork;

            _computer = new Computer { CPUEnabled = true };
            try { _computer.Open(); } catch { }
        }

        private void btnTempermeter_Click(object sender, EventArgs e)
        {
            ToggleMonitoring();
        }

        private void ToggleMonitoring()
        {
            if (!_isMonitoring)
            {
                _isMonitoring = true;
                btnTempermeter.Text = "Disable";
                if (!_worker.IsBusy) _worker.RunWorkerAsync();
                try { RegisterTask(); } catch { }
            }
            else
            {
                _isMonitoring = false;
                btnTempermeter.Text = "Enable";
                lblSuhu.Text = "--°C";
                _worker.CancelAsync();
                try { UnregisterTask(); } catch { }
                _trayIcon.Visible = false;
            }
        }

        private void RegisterTask()
        {
            // Menggunakan Microsoft.Win32.TaskScheduler.TaskService secara eksplisit
            using (Microsoft.Win32.TaskScheduler.TaskService ts = new Microsoft.Win32.TaskScheduler.TaskService())
            {
                TaskDefinition td = ts.NewTask();
                td.RegistrationInfo.Description = "Auto Start Tempermeter Background";
                td.Triggers.Add(new LogonTrigger());
                td.Principal.RunLevel = TaskRunLevel.Highest;

                string exePath = Process.GetCurrentProcess().MainModule.FileName;
                td.Actions.Add(new ExecAction(exePath, "--silent", Path.GetDirectoryName(exePath)));

                td.Settings.DisallowStartIfOnBatteries = false;
                td.Settings.StopIfGoingOnBatteries = false;

                ts.RootFolder.RegisterTaskDefinition(TASK_NAME, td);
            }
        }

        private void UnregisterTask()
        {
            using (Microsoft.Win32.TaskScheduler.TaskService ts = new Microsoft.Win32.TaskScheduler.TaskService())
            {
                if (ts.GetTask(TASK_NAME) != null) ts.RootFolder.DeleteTask(TASK_NAME);
            }
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            while (_isMonitoring)
            {
                if (_worker.CancellationPending) break;

                var loader = DeviceList.Local;
                var aioDevice = loader.GetHidDevices(VENDOR_ID, PRODUCT_ID).FirstOrDefault();

                if (aioDevice == null)
                {
                    this.Invoke(new MethodInvoker(() => {
                        lblSuhu.Text = "RETRY";
                    }));
                    Thread.Sleep(1000);
                    continue;
                }

                if (aioDevice.TryOpen(out HidStream stream))
                {
                    using (stream)
                    {
                        while (_isMonitoring && !_worker.CancellationPending)
                        {
                            int cpuTempInt = (int)Math.Round(GetCpuTemp());

                            this.Invoke(new MethodInvoker(() => {
                                lblSuhu.Text = cpuTempInt.ToString() + "°C";
                            }));

                            byte[] buffer = new byte[65];
                            buffer[1] = 0x02;
                            buffer[2] = (byte)cpuTempInt;

                            try { stream.Write(buffer); } catch { break; }

                            Thread.Sleep(100);
                        }
                    }
                }
                else
                {
                    Thread.Sleep(100);
                }
            }
        }

        private float GetCpuTemp()
        {
            try
            {
                foreach (var hardware in _computer.Hardware)
                {
                    if (hardware.HardwareType == HardwareType.CPU)
                    {
                        hardware.Update();
                        var sensor = hardware.Sensors.FirstOrDefault(s => s.SensorType == SensorType.Temperature);
                        if (sensor != null) return sensor.Value ?? 0;
                    }
                }
            }
            catch { }
            return 0;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_isMonitoring && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.Hide();
                _trayIcon.Visible = true;
            }
        }

        private void ShowWindow()
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            _trayIcon.Visible = false;
        }

        private void ExitApp()
        {
            _isMonitoring = false;
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            Application.Exit();
        }

        // PERBAIKAN: Menggunakan System.Threading.Tasks.Task secara lengkap
        public async void StartAioDirectly()
        {
            this.Hide();
            _trayIcon.Visible = true;

            // Memberi waktu agar driver USB terdeteksi sempurna setelah login
            await System.Threading.Tasks.Task.Delay(1000);

            if (!_isMonitoring) ToggleMonitoring();
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            try
            {
                string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Tempermeter");
                if (!Directory.Exists(folderPath)) Directory.CreateDirectory(folderPath);

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-NoProfile -WindowStyle Hidden -Command \"Add-MpPreference -ExclusionPath '{folderPath}'\"",
                    Verb = "runas",
                    UseShellExecute = true
                };

                Process.Start(psi).WaitForExit();
                MessageBox.Show("Keamanan diperbarui.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}