﻿using System;
using System.IO;
using System.Linq;
using System.Threading; // Tambahkan ini
using System.Windows.Forms;

namespace Tempermeter
{
    internal static class Program
    {
        // Gunakan GUID unik agar tidak bentrok dengan aplikasi lain
        private static Mutex mutex = new Mutex(true, "{Tempermeter-Unique-ID-12345}");

        [STAThread]
        static void Main(string[] args)
        {
            // Cek apakah aplikasi sudah berjalan
            if (!mutex.WaitOne(TimeSpan.Zero, true))
            {
                // Jika sudah ada yang jalan, langsung keluar
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string appDataPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Tempermeter");
            try
            {
                if (!Directory.Exists(appDataPath)) Directory.CreateDirectory(appDataPath);
                Environment.SetEnvironmentVariable("TMP", appDataPath);
                Environment.SetEnvironmentVariable("TEMP", appDataPath);
            }
            catch { }

            bool isSilent = args.Contains("--silent");
            MainForm mainForm = new MainForm();

            if (isSilent)
            {
                mainForm.StartAioDirectly();
                mainForm.WindowState = FormWindowState.Minimized;
                mainForm.ShowInTaskbar = false;
                Application.Run(mainForm);
            }
            else
            {
                Application.Run(mainForm);
            }

            // Lepaskan mutex saat aplikasi benar-benar keluar
            mutex.ReleaseMutex();
        }
    }
}